# Weekly Newsletter Sender - Plugin Assets

This directory contains visual assets for the WordPress plugin.

## Asset Requirements

### Plugin Repository Images

#### Screenshots (1200px wide)
- `screenshot-1.png` - Main settings interface 
- `screenshot-2.png` - Email design customization panel
- `screenshot-3.png` - SMTP configuration screen
- `screenshot-4.png` - Newsletter preview example

#### Banners
- `banner-772x250.png` - Low resolution banner (772x250px)
- `banner-1544x500.png` - High resolution banner (1544x500px)

#### Icons
- `icon-128x128.png` - Plugin icon (128x128px)
- `icon-256x256.png` - High resolution icon (256x256px)

### Design Guidelines

#### Color Scheme
- Primary: #2c5aa0 (Plugin header color)
- Accent: #0073aa (WordPress blue)
- Text: #333333
- Background: #f9f9f9

#### Typography
- Headers: System fonts (Arial, sans-serif)
- Body text: 14px, readable contrast
- Clean, professional appearance

#### Visual Style
- Clean, modern design
- Professional WordPress aesthetic
- Clear feature demonstrations
- Mobile-friendly layouts

### Asset Creation Tools

#### Recommended Software
- **Figma** - For UI mockups and banners
- **Canva** - Quick banner creation
- **GIMP** - Free image editing
- **Photoshop** - Professional editing
- **Sketch** - Mac design tool

#### Banner Content Ideas
- Newsletter email preview
- WordPress admin interface
- Mobile-responsive design
- Email automation workflow
- wpForo integration highlight

#### Screenshot Content
1. **Main Interface** - Show tabbed admin panel
2. **Design System** - Color picker, live preview
3. **SMTP Setup** - Configuration form
4. **Newsletter Example** - Beautiful email preview

### File Specifications

#### Image Requirements
- **Format**: PNG (preferred) or JPG
- **Quality**: High resolution, crisp text
- **Compression**: Optimized for web
- **Text**: Readable at all sizes

#### Banner Specifications
- **Low-res**: 772×250px, under 100KB
- **High-res**: 1544×500px, under 300KB
- **Content**: Plugin name, key features, visual appeal

#### Icon Specifications
- **Small**: 128×128px, under 50KB
- **Large**: 256×256px, under 100KB
- **Style**: Simple, recognizable, scalable
- **Background**: Transparent or solid

### Usage Notes

These assets are used for:
- WordPress.org plugin repository
- Plugin marketplace listings
- Documentation and marketing
- Social media promotion
- Email signatures and support

### Asset Status

- [ ] screenshot-1.png - Settings interface
- [ ] screenshot-2.png - Design customization  
- [ ] screenshot-3.png - SMTP configuration
- [ ] screenshot-4.png - Newsletter preview
- [ ] banner-772x250.png - Low-res banner
- [ ] banner-1544x500.png - High-res banner
- [ ] icon-128x128.png - Standard icon
- [ ] icon-256x256.png - High-res icon

### Creation Checklist

1. **Plan Layout** - Sketch designs first
2. **Capture Screenshots** - Use clean WordPress install
3. **Create Banners** - Highlight key features
4. **Design Icons** - Simple, memorable design
5. **Optimize Files** - Compress for web delivery
6. **Test Display** - Verify quality at different sizes
7. **Update Documentation** - Reference in README.md

### Legal Notes

- Assets must be original or properly licensed
- No copyrighted elements without permission
- WordPress trademark usage guidelines apply
- Plugin branding should be consistent

---

**To create these assets:**
1. Install the plugin in a clean WordPress environment
2. Configure it with sample data
3. Take high-quality screenshots
4. Create professional banners and icons
5. Optimize all images for web delivery